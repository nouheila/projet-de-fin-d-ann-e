<?php


function getEmail()
{
   $db = dbConnect();
    $query = $db->prepare('SELECT email FROM user WHERE email = ?');
    $query->execute([
      $_POST['email'],
    ]);
    $emailExists = $query->fetch();

	return $emailExists;
}

function getUser()

{
    $db = dbConnect();

    $query = $db->prepare('SELECT * FROM user WHERE email = :email AND mdp = :mdp');
        $query->execute([
          'mdp' => md5($_POST['mdp']),
          'email' => $_POST['email'],
        ]);
        $user = $query->fetch();
        
        return $user;
}

function addUser()
{
    $db = dbConnect();

     $query= $db->prepare('INSERT INTO user (nom, prenom, adresse, email, mdp) VALUES (?,?,?,?,?)');
     $result= $query->execute([
        $_POST['nom'],
        $_POST['prenom'],
        $_POST['adresse'],
        $_POST['email'],
        hash('md5', $_POST['mdp']),

      ]);
     return $result;
  
}

function updateUser( $id,$informations){
  $db = dbConnect();
  $query=$db->prepare("UPDATE user SET nom = ?, prenom = ?, adresse = ?, email = ?,mdp = ? WHERE id = ?");
  $result = $query -> execute([
      $informations['nom'],
      $informations['prenom'],
      $informations['adresse'],
      $informations['email'],
      hash('md5', $informations['mdp']),
      $id,

  ]);
  return $result;
}


function getUserId($id){
  $db = dbConnect();
  $query=$db->prepare("SELECT * FROM user WHERE id = ?");
  $query->execute([
      $id,
]);

  return $query->fetch();

}