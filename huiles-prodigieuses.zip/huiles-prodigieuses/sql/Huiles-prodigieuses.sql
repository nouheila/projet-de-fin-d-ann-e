-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le :  sam. 20 juin 2020 à 18:03
-- Version du serveur :  5.7.26
-- Version de PHP :  7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `Huiles-prodigieuses`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `image`) VALUES
(1, 'Huiles végétales', 'Des produits pour  chouchouter votre corps et vos cheveux ?  <br>C’est ici que vous les trouverez ! <br>Issue de l\'agriculture bioloqique, nos huiles végétales n’ont qu’un seul but :  <br>Prendre soin de vous et de notre planète !', '1.jpg'),
(3, 'Cosmétiques', 'Des produits pour chouchouter votre corps et vos cheveux ?  <br>C’est ici que vous les trouverez ! <br>Tous fabriqués en France, nos cosmétiques n’ont qu’un seul but :  <br>Prendre soin de vous et de notre planète !', '3.jpg'),
(8, 'Huiles essentielles ', 'Des produits pour vous détendre ?  <br>C’est ici que vous les trouverez ! <br>Issue de l\'agriculture biologique, nos huiles essentielles n’ont qu’un seul but :  <br>Prendre soin de vous et de notre planète !', '8.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `product` varchar(255) NOT NULL,
  `prix` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `short_description` text NOT NULL,
  `description` text NOT NULL,
  `first_image` varchar(255) DEFAULT NULL,
  `price` float NOT NULL,
  `quantity` int(11) NOT NULL,
  `from_title` text NOT NULL,
  `from_description` text NOT NULL,
  `use_title` text NOT NULL,
  `use_description` text NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`id`, `name`, `short_description`, `description`, `first_image`, `price`, `quantity`, `from_title`, `from_description`, `use_title`, `use_description`, `category_id`) VALUES
(1, 'Huile de coco ', 'Hydratante Corps & Cheveux', 'La plus réconfortante de nos huiles, “Coconut Rhapsody”  est une huile de coco<br> pure gorgée du soleil de l’océan Indien : elle vient tout droit de Madagascar.<br>\r\n\r\nSolide sous 23°C, sa texture baume fond au contact de la peau.<br>\r\n\r\nFabriquée à partir de cocotiers sauvages, issue d’un savoir-faire familial<br> transmis de génération en génération, désodorisée artisanalement, <br>notre huile de coco pure “Coconut Rhapsody” est le soin idéal pour nourrir votre peau et vos cheveux.', '1.jpg', 9.9, 14, 'D\'où ça vient  ?', 'La douceur de notre huile de coco vient des côtes <br>tropicales de l’Océan Indien.  Utilisée depuis des siècles à Madagascar, <br>cette huile est fabriquée artisanalement à partir de cocotiers sauvages,<br> sans le moindre pesticide, sans le moindre ajout ; <br>elle est désodorisée localement, artisanalement. Laissez-la fondre sur votre peau,<br> sur vos cheveux, laissez-vous transporter.', 'Comment on l\'utilise ?', 'Pour des cheveux hydratés et nourris, laissez poser “Coconut Rhapsody”<br> minimum 30 minutes (et jusqu’à toute une nuit !) sur vos longueurs<br> et pointes, lavez vos cheveux comme vous le feriez habituellement : <br>vos cheveux sont tout doux, vos pointes protégées des fourches.', 1),
(2, 'Huile de moringa ', 'Anti-Âge, Tous types de peaux', 'Notre huile de moringa est pure, vierge, pressée à froid. Issues d\'arbres sauvages de Madagascar, les graines qui donnent notre <br> huile de moringa poussent dans les meilleures conditions possibles,<br> dans le respect et l\'harmonie de la biodiversité.\r\n\r\n', '2.jpg', 12, 10, 'D\'où ça vient  ?', 'Nous avons parcouru Madagascar, nous avons sillonné les routes, les chemins. <br>Des climats chauds, arides, secs. Les terres du moringa.<br> Pour une peau nourrie, rayonnante, pour vous amener notre huile la plus puissante,<br> la plus noble : le Seigneur de la Peau.', 'Comment on l\'utilise ?', 'Très nourrissante, nous vous conseillons de l’appliquer le soir, sur le visage,<br> comme une crème de nuit.<br>\r\n\r\nPour décupler ses effets, nous vous proposons de l’utiliser en masque,<br> après un gommage. <br>\r\n\r\nDébarrassée des impuretés, votre peau profitera au mieux des bienfaits du Moringa ! ', 1),
(3, 'Huile de chanvre ', 'Anti-Âge, Peaux sèches ', '<p>Secret bien gardé, l’huile de chanvre combat les signes de l’âge comme aucune autre : parfaitement équilibrée  <br>en oméga 3, 6 et 9,elle redonne douceur et élasticité à la peau. <br>\r\n\r\nC’est une huile sèche, elle peut donc remplacer vos crèmes de jour comme de nuit. <br>Laissez-vous séduire par son odeur d’herbe fraîchement coupée ; nous, on adore ! </p>', '3.jpg', 7, 10, 'D\'où ça vient  ?', 'Le chanvre peut être vu comme une « mauvaise herbe », <br>cette plante s’acclimate à de  nombreux climats différents. <br>En France, elle pousse dans les climats tempérés de l’Est du pays; <br>chez nous, dans les Ardennes.<br> Une ancienne ferme, reconvertie dans le chanvre bio, <br>entourée par la grande forêt de hêtres et de chênes.', 'Comment on l\'utilise ?', 'Sur votre visage, Le Chanvre des Secrets remplace votre  crème de jour <br>comme de nuit et convient à toutes les peaux, même les plus sensibles.<br>\r\nQuelques gouttes sur les pointes et les longueurs en soin quotidien <br>ou en masque toute la nuit avant de faire votre shampoing habituel : <br>vos cheveux sont doux, nourris et hydratés. ', 1),
(4, 'Huile de jojoba ', 'Multi-usages, Visage et Cheveux', 'Véritable or liquide, « Jobi Jojoba » est notre huile de Jojoba pure, vierge et pressée à froid à Madagascar au bord de l’océan indien.<br> Elle n’est ni raffinée ni filtrée et garde ainsi tous ses principes actifs naturels :<br>oméga 9, vitamines B & E. <br>\r\n\r\nA chaque application, « Jobi Jojoba » nourrit votre peau et la <br>protège de la déshydratation :ses acides gras agissent comme une barrière.', '4.jpg', 8, 10, 'D\'où ça vient  ?', 'L’huile de jojoba, si recherchée... Notre huile de jojoba, si pure,<br> vient d’arbres sauvages du Sud de Madagascar : <br>un climat chaud, sec une nature sauvage et préservée.<br> Des conditions optimales pour notre puissante et douce Jobi Jojoba, <br>pour vous redonner une peau souple et nourrie.', 'Comment on l\'utilise ?', 'Le matin, appliquez-la comme une crème de jour, <br>une petite quantité suffit.  Et en plus, elle constitue une excellente base de maquillage ! <br> Sur le corps, seule ou mélangée à quelques gouttes d’huile essentielle, <br>en massage circulaire, elle raffermit et nourrit votre peau.', 1),
(5, 'Huile de ricin', 'Masque Avant Shampoing, ', '« Le fabuleux destin de l’huile de ricin » favorise la pousse des cheveux, gaine la fibre capillaire pour les rendre plus forts et plus épais. <br>Notre huile de ricin pure est issue des Terres Rouges de Madagascar :<br> gorgée de vitamines E et d’oméga 6 et 9, naturellement très concentrée en acide ricinoléïque,<br> elle fortifie vos cheveux, cils et ongles. ', '5.jpg', 6, 10, 'D\'où ça vient  ?', 'Des paysages lunaires, infinis. Des étendues préservées, protégées.<br> L’intensité et la beauté et notre huile de ricin vierge et pure. <br>Des arbres sauvages, nourris au soleil puissant de Madagascar,<br> sans le moindre engrais ou ajout chimique.<br> Le meilleur pour donner force, souplesse et brillance à vos cheveux, quels qu’ils soient.', 'Comment on l\'utilise ?', 'Avant chaque shampooing, appliquez-la sur votre cuir chevelu <br>en massant du bout des doigts pour activer la microcirculation sanguine, <br>laissez poser quelques heures puis lavez vos cheveux :<br> ils deviennent doux et brillants ! <br> Massez vos ongles et vos cuticules avec une toute petite quantité d’huile <br>pour les rendre rapidement  plus longs et résistants. ', 1),
(6, 'Huile de ricin rouge', 'Masque Avant Shampoing, ', '« Le fabuleux destin de l’huile de ricin » favorise la pousse des cheveux, gaine la fibre capillaire pour les rendre plus forts et plus épais. <br>Notre huile de ricin pure est issue des Terres Rouges de Madagascar :<br> gorgée de vitamines E et d’oméga 6 et 9, naturellement très concentrée en acide ricinoléïque,<br> elle fortifie vos cheveux, cils et ongles. ', '6.jpg', 7, 10, 'D\'où ça vient  ?', 'Des paysages lunaires, infinis. Des étendues préservées, protégées.<br> L’intensité et la beauté et notre huile de ricin vierge et pure. <br>Des arbres sauvages, nourris au soleil puissant de Madagascar,<br> sans le moindre engrais ou ajout chimique.<br> Le meilleur pour donner force, souplesse et brillance à vos cheveux, quels qu’ils soient.', 'Comment on l\'utilise ?', 'Avant chaque shampooing, appliquez-la sur votre cuir chevelu <br>en massant du bout des doigts pour activer la microcirculation sanguine, <br>laissez poser quelques heures puis lavez vos cheveux : ils deviennent doux et brillants ! <br> Massez vos ongles et vos cuticules avec une toute petite quantité d’huile <br>pour les rendre rapidement  plus longs et résistants. ', 1),
(7, 'Huile d\'avocat', 'Nourrissante, Peaux et cheveux secs\r\n', 'Notre huile d’avocat « Captain avocat » est obtenue à partir des avocats sauvages des hauts plateaux malgaches. <br>Dans le plus grand respect de la biodiversité locale, sans irrigation, sans apport d\'eau, sans surexploitation des ressources naturelles.<br> C\'est ce qui donne une puissance inégalée à notre huile d\'avocat. <br>Particulièrement riche en vitamines, puissante et issue du commerce équitable.<br> Cette huile aux super pouvoirs est votre nouvel allié pour lutter contre vieillissement cutané, <br>raffermir votre peau et lui rendre tout son éclat !', '7.jpg', 9, 10, 'D\'où ça vient  ?', 'Nos avocats sont issus d’avocatiers de villages <br>de la région de Fianarantsoa, à Madagascar.<br> Ces régions des hauts plateaux de la région<br> leur offrent un climat violemment ensoleillé et humide.<br> Des villages de passionnés, un climat idéal, une production naturelle, bio.<br> La clef pour le meilleur soin anti-âge est là. Simplement.', 'Comment on l\'utilise ?', 'Sur la peau, appliquez « Captain Avocat » le soir de préférence.<br> Elle s’utilise aussi bien sur le visage <br>que sur les zones plus délicates : <br>le contour des yeux et le cou.  Pour les cheveux, <br>appliquez  en masque une fois par semaine sur les longueurs et les pointes, <br>laisser poser minimum une heure et faites votre shampoing habituel !', 1),
(8, 'Huile de baobab', 'Hydratation Intense, Cheveux très secs', 'Le baobab est originaire d\'Afrique et de Madagascar. Il est un des emblèmes  <br>de l\'île grâce à la célèbre \"allée\" des baobabs qui fait le bonheur des touristes à Madagascar et leur laisse des souvenirs uniques en tête !<br> L\'huile de baobab est excellente pour prendre soin de sa peau. <br> Elle vient tout droit de Madagascar, là où ses sœurs proviennent davantage du Sénégal, <br>dont la filière du baobab est plus industrialisée.', '8.jpg', 9, 10, 'D\'où ça vient  ?', 'Il existe 8 espèces de baobab ; sur le continent Africain,<br> une seule est présente. 7 existent sur l’île de Madagascar,<br> dont 6 uniquement ici. C’est de l’une de ces espèces <br>qu\'est issue notre huile de baobab. Dans le sud-est de l’île,<br> au climat aride et sec, où poussent les plus incroyables <br>forêts de baobabs au monde. Une huile de baobab comme<br> vous ne l’avez jamais vue, une hydratation puissante et intense.<br> Pour vous!', 'Comment on l\'utilise ?', 'Pour vos cheveux, à utiliser sur les longueurs, en masque.<br> Si vous le pouvez, laissez le masque toute la nuit et prenez votre shampoing habituel le lendemain.<br> Pour la peau, frottez l\'huile avec votre main pour la réchauffer,<br> jusqu\'à ce qu\'elle ait une texture suffisamment liquide. <br>Appliquez alors l\'huile sur la partie sèche, endommagée de votre peau.', 1),
(9, 'Huile de cameline', 'Sèche, Riche en Oméga 3 et 6', 'Elle débarque tout droit de Picardie (oui oui !), « Cameline au pays des Merveilles » est notre huile de cameline pure et<br> issue de l’agriculture biologique.<br> C’est une huile anti-âge naturellement très riche en oméga 3, 6 et 9 : <br>elle régule la production de sébum, lutte contre l’apparition des ridules liées à la déshydratation, <br>apporte éclat et souplesse à la peau.\r\n<br>\r\nEt comme si cela ne suffisait pas, c’est une huile sèche :<br> elle ne laisse donc aucun film gras sur la peau !', '9.jpg', 6, 10, 'D\'où ça vient  ?', 'C’est dans une plaine Picarde, dans un champ de lentilles bio que pousse notre cameline.<br> La cameline pousse dans ce climat tempéré en servant<br> de tutrice aux pousses de lentilles : <br>un exemple d’agriculture biologique, où les deux plantes se soutiennent, naturellement.', 'Comment on l\'utilise ?', 'Utilisez la le matin à la place de votre crème de jour,<br> sa texture sèche en fait une excellente base de maquillage. <br>  Sur le corps, elle fait une parfaite base d’huile de massage.  <br>Pour aller plus loin : ajoutez-y quelques gouttes d’huile essentielle pour plus de sensorialité… ', 1),
(10, 'Huile de kukui', 'Huile sèche raffermissante, Visage et Corps', 'On vous a déniché la perle rare ! L’huile de kukui est particulièrement nourrissante et a la particularité d’être une huile sèche,<br> elle pénètre donc la peau très rapidement. Sur le visage, elle s’utilise comme crème de jour <br>et constitue une parfaite base de maquillage.<br>\r\n\r\nSur le corps, elle adoucit et raffermit la peau sans laisser de film gras.<br> Elle est parfaite, on vous dit !', '10.jpg', 9, 10, 'D\'où ça vient  ?', 'Nous sommes allés chercher cette huile méconnue mais si nourrissante et si facile à utiliser dans l’Est de Madagascar.<br> Parce que nous recherchons le meilleur pour vous,<br> des savoir-faire ancestraux lointains ou oubliés,<br> nous avons ramené ce trésor de la grande île, connu sous le nom de Bakoly.', 'Comment on l\'utilise ?', 'Comptez une pipette d\'huile pour hydrater une main. <br> Huile sèche très pénétrante à appliquer sur le corps, en routine matin ou soir. <br>Elle ne laisse pas de film gras !  De même pour le visage.', 1),
(11, 'Huile de marula', 'Nourrissante, Peaux sèches ', 'L’huile de marula est une huile sèche pénétrant rapidement la peau.Elle est Idéale pour réparer les peaux desséchées ou abîmées. <br>Particulièrement riche en vitamines E, C, en acides gras essentiels et pleine d\'antioxydants, c’est un soin anti-âge qui protège la peau : <br>elle agit efficacement contre les ridules et laisse la peau douce et protégée.', '11.jpg', 10, 10, 'D\'où ça vient  ?', 'Une nature préservée. Des paysages dignes du Roi Lion.<br> C’est dans ces conditions arides que les graines de Marula se gorgent de vitamines et d’antioxydants.<br> Et c’est dans ces conditions sauvages que nous récoltons les meilleures graines <br>pour notre huile de Marula pure, l’huile aux trésors.', 'Comment on l\'utilise ?', 'Pour une utilisation express, appliquez l\'huile de marula sur vos pointes : <br>une noisette sur vos cheveux. L\'effet démêlant, assouplissant est rapidement visible.<br> En soin de peau, vous pouvez l\'utilisez comme une crème de jour !<br> Une noisette d\'huile de marula pour une main, massez, laissez l\'huile de marula pénétrer votre peau.', 1),
(12, 'Ricin enchanteur', 'Masque avant shampoing', 'Laissez parler la tonicité de l’ylang-ylang et la puissance de l’huile de ricin ! <br>En masque capillaire, notre huile “Ricin l’enchanteur” nourrit vos cheveux secs en profondeur, <br>favorise leur pousse et les renforce dès la première utilisation.Cheveux nourris et brillants, naturellement.', '12.jpg', 10, 10, 'D\'où ça vient  ?', 'Des paysages lunaires, infinis. Des étendues préservées, protégées.<br> L’intensité et la beauté et notre huile de ricin vierge et pure. <br>Des arbres sauvages, nourris au soleil puissant de Madagascar,<br> sans le moindre engrais ou ajout chimique.<br> Le meilleur pour donner force, souplesse et brillance à vos cheveux, quels qu’ils soient.', 'Comment on l\'utilise ?', 'Avant chaque shampooing, appliquez-la sur votre cuir chevelu <br>en massant du bout des doigts pour activer la microcirculation sanguine, <br>laissez poser quelques heures puis lavez vos cheveux : ils deviennent doux et brillants ! <br> Massez vos ongles et vos cuticules avec une toute petite quantité d’huile <br>pour les rendre rapidement  plus longs et résistants. ', 1),
(13, 'Skin city', 'Sérum de jour', 'La peau du visage est soumise à des conditions extrêmes :<br>  la météo, la pollution, le stress sont autant de facteurs qui favorisent la déshydratation et l’apparition de ridules. \r\n<br>\r\nCette alliance d’huiles pures et essentielles reconnues pour leurs propriétés protectrices, nourrissantes et hydratantes <br>sera votre nouvelle alliée contre le temps ! ', '13.jpg', 12, 10, 'D\'où ça vient  ?', 'Skin City mélange des climats et des terres différentes pour vous apporter ses richesses.<br> Les bords de l’Océan Indien, région chaude et régulièrement humide,<br> pour le kukui ; les terres rouges et arides pour le moringa ;<br> les terres vertes et tempérées du Sud-Ouest de la France pour l’huile de carthame ;<br> les hauts plateaux de Madagascar pour le citron sauvage.', 'Comment on l\'utilise ?', 'Appliquez matin et soir une pipette de Skin City sur le visage et le cou, préalablement nettoyés.<br> Notre sérum est à base d’huiles sèches, il est tout simple d’utilisation ;)', 1),
(14, ' Huile de ravintsara', 'Anti-fatigue, Anti-Anxiété, ', 'Le Ravintsara se traduit par la \"bonne feuille\" en Malgache, <br>c\'est une plante bien connue sur lîle pour faciliter le sommeil, lutter contre la nervosité et renforcer les défenses naturelles.<br> Utilisée depuis des millénaires pour soigner et purifier les corps, <br>c\'est un antiseptique naturel qui vous permet aussi de vous relaxer !', '14.jpg', 3, 10, 'D\'où ça vient  ?', 'Les Hauts Plateaux malgaches nous fournissent d\'excellentes <br>huiles essentielles : un climat chaud, sans être trop lourd <br>de larges étendues de nature intacte de tout produit chimique ;<br> un climat idéal. C’est autour d’Antsirabe que sont réunis ces conditions : <br>beaucoup de nos meilleures huiles essentielles viennent de là.', 'Comment on l\'utilise ?', 'En inhalation : quelques gouttes dans un grand bol<br> d\'eau très chaud, vous respirez les vapeurs. <br>Ou directement quelques gouttes sur un mouchoir que vous sentez', 8),
(15, 'Huile de citriodora', ' Musculaires, Purifiante', 'L\'eucalyptus citronné est un arbre pouvant atteindre 50m de haut faisant partie de la même famille que le tea tree, le niaouli ou le myrte. <br>La plante est utilisée depuis des siècles pour ses nombreuses vertus médicinales.<br> L\'huile essentielle d\'eucalyptus citronné favorise l’apaisement et la détente.<br> Les feuilles sont distillées à la vapeur d\'eau pour en tirer les meilleurs composés actifs !', '15.jpg', 3, 10, 'D\'où ça vient  ?', 'Les Hauts Plateaux malgaches nous fournissent d\'excellentes <br>huiles essentielles : un climat chaud, sans être trop lourd <br>de larges étendues de nature intacte de tout produit chimique ;<br> un climat idéal. C’est autour d’Antsirabe que sont réunis ces conditions : <br>beaucoup de nos meilleures huiles essentielles viennent de là.', 'Comment on l\'utilise ?', 'En inhalation : quelques gouttes dans un grand bol<br> d\'eau très chaud, vous respirez les vapeurs. <br>Ou directement quelques gouttes sur un mouchoir que vous sentez', 8),
(16, 'Huile de geranium', ' Purifiante, Apaisante', 'Elle est une huile essentielle cosmétique par excellence. <br>Très polyvalente, elle équilibre la sécrétion de sébum, la substance grasse produite par votre corps et qui préserve l\'élasticité de l\'épiderme. <br>Favorisant la circulation et purifiant la surface de la peau, elle est un très bon allié cosmétique<br> et s\'utilise en synergie d\'huiles nobles telles que l\'huile de chanvre et l\'huile de moringa.', '16.jpg', 5, 10, 'D\'où ça vient  ?', 'Les Hauts Plateaux malgaches nous fournissent d\'excellentes <br>huiles essentielles : un climat chaud, sans être trop lourd <br>de larges étendues de nature intacte de tout produit chimique ;<br> un climat idéal. C’est autour d’Antsirabe que sont réunis ces conditions : <br>beaucoup de nos meilleures huiles essentielles viennent de là.', 'Comment on l\'utilise ?', 'Pour un soin de la peau régulier, anti-âge, nous vous conseillons de mélanger l\'huile essentielle de géranium bourbon avec une huile végétale sèche, pour le visage ou le corps. Pour le visage, quelques gouttes d\'huile essentielle de géranium avec de l\'huile de chanvre pure, pour les peaux sèches, ou de jojoba, pour les peaux mixtes ', 8),
(17, 'Huile de katrafay', 'Anti-inflammatoire,  Après-Sport', 'L\'huile essentielle de Katrafay, bio, est utilisée comme huile apaisante, calmer des douleurs articulaires.<br>\r\nElle s\'applique en massage mélangée à une huile végétale, le long des articulations endolories et des muscles fatigués. <br>\r\n\r\nChez nous, tout est équitable, artisanal et respectueux de l\'environnement', '17.jpg', 4, 10, 'D\'où ça vient  ?', 'C’est un petit arbuste robuste qui nous donne notre huile essentielle de Katrafay. Taillé pour les climats les plus secs, les plus rudes, le Katrafay est un arbre de brousse endémique de Madagascar : il pousse dans la poussière des baobabs, au Sud-Ouest du pays.', 'Comment on l\'utilise ?', 'En inhalation : quelques gouttes dans un grand bol<br> d\'eau très chaud, vous respirez les vapeurs. <br>Ou directement quelques gouttes sur un mouchoir que vous sentez', 8),
(18, 'Huile de lantana', 'Détente,  Calme', 'Détendez-vous, calmez-vous. Quelques gouttes d\'huiles de lantana et vous serez au bord de l\'Océan Indien, reposée pour la journée. <br>Vos muscles vous remercieront. <br>\r\n\r\nL\'huile essentielle de Lantana est reconnue comme une huile essentielle facilitant le sommeil,<br> et généralement l\'huile essentielle de Lantana est une excellente huile pour apaiser les tensions : <br>c\'est une huile essentielle calmante.', '18.jpg', 4, 10, 'D\'où ça vient  ?', 'Les Hauts Plateaux malgaches nous fournissent d\'excellentes <br>huiles essentielles : un climat chaud, sans être trop lourd <br>de larges étendues de nature intacte de tout produit chimique ;<br> un climat idéal. C’est autour d’Antsirabe que sont réunis ces conditions : <br>beaucoup de nos meilleures huiles essentielles viennent de là.', 'Comment on l\'utilise ?', 'En inhalation : quelques gouttes dans un grand bol<br> d\'eau très chaud, vous respirez les vapeurs. <br>Ou directement quelques gouttes sur un mouchoir que vous sentez', 8),
(19, 'Huile de niaouli', 'Jambes Lourdes, Anti-stress, ', 'Le Niaouli est un arbre originaire de la Nouvelle-Calédonie, de la famille des Myrtacées. <br>\r\nHuile essentielle stimulant le système immunitaire, elle est énergisante et purifiante,<br> \r\nest connue pour stimuler les défenses naturelles et s\'utilise en accompagnement en cas d\'infections hivernales.<br> Elle est utile pour favoriser le confort circulatoire et les jambes légères.', '19.jpg', 4, 10, 'D\'où ça vient  ?', 'Il faut un climat chaud et suffisamment humide pour que le niaouli puisse pousser dans des conditions optimales. C’est le même paysage que l’avocat, les mêmes conditions de culture, les mêmes méthodes : des plantes sauvages au sud de Fianarantsoa, un savoir-faire artisanal, familial, minutieux.', 'Comment on l\'utilise ?', 'En inhalation : quelques gouttes dans un grand bol<br> d\'eau très chaud, vous respirez les vapeurs. <br>Ou directement quelques gouttes sur un mouchoir que vous sentez', 8),
(20, 'Huile de palmarosa', 'Sensuelle, Déodorante, Purifiante', 'Laissez-vous séduire par la douce odeur de rose de notre huile essentielle de Palmarosa... <br>Et soyez surpris par la force de ses effets. <br>Purifiante et tonifiante cutanée, elle lutte contre les impuretés de la peau, en particulier l\'acnée. <br>Sur le cuir chevelu, elle lutte contre les pellicules en assainissant votre peau. <br>Utilisée régulièrement elle lutte contre l\'apparition de la cellulite. <br>Une douce merveille !', '20.jpg', 4, 10, 'D\'où ça vient  ?', 'Les Hauts Plateaux malgaches nous fournissent d\'excellentes <br>huiles essentielles : un climat chaud, sans être trop lourd <br>de larges étendues de nature intacte de tout produit chimique ;<br> un climat idéal. C’est autour d’Antsirabe que sont réunis ces conditions : <br>beaucoup de nos meilleures huiles essentielles viennent de là.', 'Comment on l\'utilise ?', 'En inhalation : quelques gouttes dans un grand bol<br> d\'eau très chaud, vous respirez les vapeurs. <br>Ou directement quelques gouttes sur un mouchoir que vous sentez', 8),
(21, 'Huile  de poivre noir ', 'Tonus, Stimulation', 'L\'huile essentielle de Poivre noir tonifie vos muscles, les réchauffe avant tout effort physique.<br> Une odeur musclée, forte, comme nulle autre pareille.<br> L\'huile essentielle de poivre noir réveille vos muscles lorsqu\'ils sont fatigués : <br>appliquée sur vos muscles l\'huile essentielle de poivre noir les prépare à un effort physique ou leur redonne du tonus après une séance musclée.', '21.jpg', 4, 10, 'D\'où ça vient  ?', 'Les Hauts Plateaux malgaches nous fournissent d\'excellentes <br>huiles essentielles : un climat chaud, sans être trop lourd <br>de larges étendues de nature intacte de tout produit chimique ;<br> un climat idéal. C’est autour d’Antsirabe que sont réunis ces conditions : <br>beaucoup de nos meilleures huiles essentielles viennent de là.', 'Comment on l\'utilise ?', 'En inhalation : quelques gouttes dans un grand bol<br> d\'eau très chaud, vous respirez les vapeurs. <br>Ou directement quelques gouttes sur un mouchoir que vous sentez', 8),
(22, 'Huile de saro', ' Antibactérienne, Antivirale', 'L\'huile essentielle de Saro provient d\'une plante endémique à Madagascar, <br>bien connue sur l\'Île pour ses propriétés en cas de baisse de forme. <br>Anti-bactérienne, antivirale, l\'huile essentielle de Saro soutient vos défenses immunitaires. <br>Un petit rhume, un coup de froid, bref, c\'est l\'hiver, vous êtes affaiblie,<br> et l\'huile essentielle de Saro est votre meilleure alliée ! ', '22.jpg', 4, 10, 'D\'où ça vient  ?', 'Les Hauts Plateaux malgaches nous fournissent d\'excellentes <br>huiles essentielles : un climat chaud, sans être trop lourd <br>de larges étendues de nature intacte de tout produit chimique ;<br> un climat idéal. C’est autour d’Antsirabe que sont réunis ces conditions : <br>beaucoup de nos meilleures huiles essentielles viennent de là.', 'Comment on l\'utilise ?', 'En inhalation : quelques gouttes dans un grand bol<br> d\'eau très chaud, vous respirez les vapeurs. <br>Ou directement quelques gouttes sur un mouchoir que vous sentez', 8),
(23, 'Huile d\'ylang ylang', 'Fortifiante, Purifiante,', 'L\'huile essentielle d\'Ylang Ylang est utilisée pour purifier et fortifier vos cheveux et votre peau.<br> Elle régule la production de sébum ce qui en fait une excellente alliée contre vos problèmes réguliers :<br> cheveux toujours secs, cassant, pellicules, l\'huile essentielle d\'Ylang ylang fortifie sur le long terme vos cheveux.\r\n\r\n', '23.jpg', 6, 10, 'D\'où ça vient  ?', 'Les Hauts Plateaux malgaches nous fournissent d\'excellentes <br>huiles essentielles : un climat chaud, sans être trop lourd <br>de larges étendues de nature intacte de tout produit chimique ;<br> un climat idéal. C’est autour d’Antsirabe que sont réunis ces conditions : <br>beaucoup de nos meilleures huiles essentielles viennent de là.', 'Comment on l\'utilise ?', 'En inhalation : quelques gouttes dans un grand bol<br> d\'eau très chaud, vous respirez les vapeurs. <br>Ou directement quelques gouttes sur un mouchoir que vous sentez', 8),
(24, 'Huile de citron', ' Désinfectante, Purifiante', 'Son odeur est sucrée, douce : un vrai délice !<br>\r\nPlus que ça, notre huile essentielle de citron sauvage a des propriétés assainissantes puissantes.<br> Très facile d\'utilsation : quelques gouttes mélangées avec votre soin habituel pour assainir votre peau ou simplement en diffusion pour son odeur. <br>Tellement d\'utilisation pour ce petit sucre !', '24.jpg', 6, 10, 'D\'où ça vient  ?', 'Les Hauts Plateaux malgaches nous fournissent d\'excellentes <br>huiles essentielles : un climat chaud, sans être trop lourd <br>de larges étendues de nature intacte de tout produit chimique ;<br> un climat idéal. C’est autour d’Antsirabe que sont réunis ces conditions : <br>beaucoup de nos meilleures huiles essentielles viennent de là.', 'Comment on l\'utilise ?', 'En inhalation : quelques gouttes dans un grand bol<br> d\'eau très chaud, vous respirez les vapeurs. <br>Ou directement quelques gouttes sur un mouchoir que vous sentez', 8),
(45, 'Ricin enchanteur', 'Masque avant shampoing', 'Laissez parler la tonicité de l’ylang-ylang et la puissance de l’huile de ricin ! <br>En masque capillaire, notre huile “Ricin l’enchanteur” nourrit vos cheveux secs en profondeur, <br>favorise leur pousse et les renforce dès la première utilisation.Cheveux nourris et brillants, naturellement.', '12.jpg', 10, 10, 'D\'où ça vient  ?', 'Des paysages lunaires, infinis. Des étendues préservées, protégées.<br> L’intensité et la beauté et notre huile de ricin vierge et pure. <br>Des arbres sauvages, nourris au soleil puissant de Madagascar,<br> sans le moindre engrais ou ajout chimique.<br> Le meilleur pour donner force, souplesse et brillance à vos cheveux, quels qu’ils soient.', 'Comment on l\'utilise ?', 'Avant chaque shampooing, appliquez-la sur votre cuir chevelu <br>en massant du bout des doigts pour activer la microcirculation sanguine, <br>laissez poser quelques heures puis lavez vos cheveux : ils deviennent doux et brillants ! <br> Massez vos ongles et vos cuticules avec une toute petite quantité d’huile <br>pour les rendre rapidement  plus longs et résistants. ', 3),
(46, 'Huile de moringa ', 'Anti-Âge, Tous types de peaux', 'Notre huile de moringa est pure, vierge, pressée à froid. Issues d\'arbres sauvages de Madagascar, les graines qui donnent notre <br> huile de moringa poussent dans les meilleures conditions possibles,<br> dans le respect et l\'harmonie de la biodiversité.\r\n\r\n', '2.jpg', 12, 10, 'D\'où ça vient  ?', 'Nous avons parcouru Madagascar, nous avons sillonné les routes, les chemins. <br>Des climats chauds, arides, secs. Les terres du moringa.<br> Pour une peau nourrie, rayonnante, pour vous amener notre huile la plus puissante,<br> la plus noble : le Seigneur de la Peau.', 'Comment on l\'utilise ?', 'Très nourrissante, nous vous conseillons de l’appliquer le soir, sur le visage,<br> comme une crème de nuit.<br>\r\n\r\nPour décupler ses effets, nous vous proposons de l’utiliser en masque,<br> après un gommage. <br>\r\n\r\nDébarrassée des impuretés, votre peau profitera au mieux des bienfaits du Moringa ! ', 3),
(47, 'Huile d\'avocat', 'Nourrissante, Peaux et cheveux secs\r\n', 'Notre huile d’avocat « Captain avocat » est obtenue à partir des avocats sauvages des hauts plateaux malgaches. <br>Dans le plus grand respect de la biodiversité locale, sans irrigation, sans apport d\'eau, sans surexploitation des ressources naturelles.<br> C\'est ce qui donne une puissance inégalée à notre huile d\'avocat. <br>Particulièrement riche en vitamines, puissante et issue du commerce équitable.<br> Cette huile aux super pouvoirs est votre nouvel allié pour lutter contre vieillissement cutané, <br>raffermir votre peau et lui rendre tout son éclat !', '7.jpg', 9, 10, 'D\'où ça vient  ?', 'Nos avocats sont issus d’avocatiers de villages <br>de la région de Fianarantsoa, à Madagascar.<br> Ces régions des hauts plateaux de la région<br> leur offrent un climat violemment ensoleillé et humide.<br> Des villages de passionnés, un climat idéal, une production naturelle, bio.<br> La clef pour le meilleur soin anti-âge est là. Simplement.', 'Comment on l\'utilise ?', 'Sur la peau, appliquez « Captain Avocat » le soir de préférence.<br> Elle s’utilise aussi bien sur le visage <br>que sur les zones plus délicates : <br>le contour des yeux et le cou.  Pour les cheveux, <br>appliquez  en masque une fois par semaine sur les longueurs et les pointes, <br>laisser poser minimum une heure et faites votre shampoing habituel !', 3),
(48, 'Huile de marula', 'Nourrissante, Peaux sèches ', 'L’huile de marula est une huile sèche pénétrant rapidement la peau.Elle est Idéale pour réparer les peaux desséchées ou abîmées. <br>Particulièrement riche en vitamines E, C, en acides gras essentiels et pleine d\'antioxydants, c’est un soin anti-âge qui protège la peau : <br>elle agit efficacement contre les ridules et laisse la peau douce et protégée.', '11.jpg', 10, 10, 'D\'où ça vient  ?', 'Une nature préservée. Des paysages dignes du Roi Lion.<br> C’est dans ces conditions arides que les graines de Marula se gorgent de vitamines et d’antioxydants.<br> Et c’est dans ces conditions sauvages que nous récoltons les meilleures graines <br>pour notre huile de Marula pure, l’huile aux trésors.', 'Comment on l\'utilise ?', 'Pour une utilisation express, appliquez l\'huile de marula sur vos pointes : <br>une noisette sur vos cheveux. L\'effet démêlant, assouplissant est rapidement visible.<br> En soin de peau, vous pouvez l\'utilisez comme une crème de jour !<br> Une noisette d\'huile de marula pour une main, massez, laissez l\'huile de marula pénétrer votre peau.', 3),
(49, 'Huile de coco ', 'Hydratante Corps & Cheveux', 'La plus réconfortante de nos huiles, “Coconut Rhapsody”  est une huile de coco<br> pure gorgée du soleil de l’océan Indien : elle vient tout droit de Madagascar.<br>\r\n\r\nSolide sous 23°C, sa texture baume fond au contact de la peau.<br>\r\n\r\nFabriquée à partir de cocotiers sauvages, issue d’un savoir-faire familial<br> transmis de génération en génération, désodorisée artisanalement, <br>notre huile de coco pure “Coconut Rhapsody” est le soin idéal pour nourrir votre peau et vos cheveux.', '1.jpg', 9.9, 14, 'D\'où ça vient  ?', 'La douceur de notre huile de coco vient des côtes <br>tropicales de l’Océan Indien.  Utilisée depuis des siècles à Madagascar, <br>cette huile est fabriquée artisanalement à partir de cocotiers sauvages,<br> sans le moindre pesticide, sans le moindre ajout ; <br>elle est désodorisée localement, artisanalement. Laissez-la fondre sur votre peau,<br> sur vos cheveux, laissez-vous transporter.', 'Comment on l\'utilise ?', 'Pour des cheveux hydratés et nourris, laissez poser “Coconut Rhapsody”<br> minimum 30 minutes (et jusqu’à toute une nuit !) sur vos longueurs<br> et pointes, lavez vos cheveux comme vous le feriez habituellement : <br>vos cheveux sont tout doux, vos pointes protégées des fourches.', 3),
(50, 'Huile de ricin rouge', 'Masque Avant Shampoing, ', '« Le fabuleux destin de l’huile de ricin » favorise la pousse des cheveux, gaine la fibre capillaire pour les rendre plus forts et plus épais. <br>Notre huile de ricin pure est issue des Terres Rouges de Madagascar :<br> gorgée de vitamines E et d’oméga 6 et 9, naturellement très concentrée en acide ricinoléïque,<br> elle fortifie vos cheveux, cils et ongles. ', '6.jpg', 7, 10, 'D\'où ça vient  ?', 'Des paysages lunaires, infinis. Des étendues préservées, protégées.<br> L’intensité et la beauté et notre huile de ricin vierge et pure. <br>Des arbres sauvages, nourris au soleil puissant de Madagascar,<br> sans le moindre engrais ou ajout chimique.<br> Le meilleur pour donner force, souplesse et brillance à vos cheveux, quels qu’ils soient.', 'Comment on l\'utilise ?', 'Avant chaque shampooing, appliquez-la sur votre cuir chevelu <br>en massant du bout des doigts pour activer la microcirculation sanguine, <br>laissez poser quelques heures puis lavez vos cheveux : ils deviennent doux et brillants ! <br> Massez vos ongles et vos cuticules avec une toute petite quantité d’huile <br>pour les rendre rapidement  plus longs et résistants. ', 3),
(51, 'Huile de baobab', 'Hydratation Intense, Cheveux très secs', 'Le baobab est originaire d\'Afrique et de Madagascar. Il est un des emblèmes  <br>de l\'île grâce à la célèbre \"allée\" des baobabs qui fait le bonheur des touristes à Madagascar et leur laisse des souvenirs uniques en tête !<br> L\'huile de baobab est excellente pour prendre soin de sa peau. <br> Elle vient tout droit de Madagascar, là où ses sœurs proviennent davantage du Sénégal, <br>dont la filière du baobab est plus industrialisée.', '8.jpg', 9, 10, 'D\'où ça vient  ?', 'Il existe 8 espèces de baobab ; sur le continent Africain,<br> une seule est présente. 7 existent sur l’île de Madagascar,<br> dont 6 uniquement ici. C’est de l’une de ces espèces <br>qu\'est issue notre huile de baobab. Dans le sud-est de l’île,<br> au climat aride et sec, où poussent les plus incroyables <br>forêts de baobabs au monde. Une huile de baobab comme<br> vous ne l’avez jamais vue, une hydratation puissante et intense.<br> Pour vous!', 'Comment on l\'utilise ?', 'Pour vos cheveux, à utiliser sur les longueurs, en masque.<br> Si vous le pouvez, laissez le masque toute la nuit et prenez votre shampoing habituel le lendemain.<br> Pour la peau, frottez l\'huile avec votre main pour la réchauffer,<br> jusqu\'à ce qu\'elle ait une texture suffisamment liquide. <br>Appliquez alors l\'huile sur la partie sèche, endommagée de votre peau.', 3),
(52, 'Huile de jojoba ', 'Multi-usages, Visage et Cheveux', 'Véritable or liquide, « Jobi Jojoba » est notre huile de Jojoba pure, vierge et pressée à froid à Madagascar au bord de l’océan indien.<br> Elle n’est ni raffinée ni filtrée et garde ainsi tous ses principes actifs naturels :<br>oméga 9, vitamines B & E. <br>\r\n\r\nA chaque application, « Jobi Jojoba » nourrit votre peau et la <br>protège de la déshydratation :ses acides gras agissent comme une barrière.', '4.jpg', 8, 10, 'D\'où ça vient  ?', 'L’huile de jojoba, si recherchée... Notre huile de jojoba, si pure,<br> vient d’arbres sauvages du Sud de Madagascar : <br>un climat chaud, sec une nature sauvage et préservée.<br> Des conditions optimales pour notre puissante et douce Jobi Jojoba, <br>pour vous redonner une peau souple et nourrie.', 'Comment on l\'utilise ?', 'Le matin, appliquez-la comme une crème de jour, <br>une petite quantité suffit.  Et en plus, elle constitue une excellente base de maquillage ! <br> Sur le corps, seule ou mélangée à quelques gouttes d’huile essentielle, <br>en massage circulaire, elle raffermit et nourrit votre peau.', 3),
(53, 'Huile de ricin', 'Masque Avant Shampoing, ', '« Le fabuleux destin de l’huile de ricin » favorise la pousse des cheveux, gaine la fibre capillaire pour les rendre plus forts et plus épais. <br>Notre huile de ricin pure est issue des Terres Rouges de Madagascar :<br> gorgée de vitamines E et d’oméga 6 et 9, naturellement très concentrée en acide ricinoléïque,<br> elle fortifie vos cheveux, cils et ongles. ', '5.jpg', 6, 10, 'D\'où ça vient  ?', 'Des paysages lunaires, infinis. Des étendues préservées, protégées.<br> L’intensité et la beauté et notre huile de ricin vierge et pure. <br>Des arbres sauvages, nourris au soleil puissant de Madagascar,<br> sans le moindre engrais ou ajout chimique.<br> Le meilleur pour donner force, souplesse et brillance à vos cheveux, quels qu’ils soient.', 'Comment on l\'utilise ?', 'Avant chaque shampooing, appliquez-la sur votre cuir chevelu <br>en massant du bout des doigts pour activer la microcirculation sanguine, <br>laissez poser quelques heures puis lavez vos cheveux :<br> ils deviennent doux et brillants ! <br> Massez vos ongles et vos cuticules avec une toute petite quantité d’huile <br>pour les rendre rapidement  plus longs et résistants. ', 3),
(54, 'Huile de kukui', 'Huile sèche raffermissante, Visage et Corps', 'On vous a déniché la perle rare ! L’huile de kukui est particulièrement nourrissante et a la particularité d’être une huile sèche,<br> elle pénètre donc la peau très rapidement. Sur le visage, elle s’utilise comme crème de jour <br>et constitue une parfaite base de maquillage.<br>\r\n\r\nSur le corps, elle adoucit et raffermit la peau sans laisser de film gras.<br> Elle est parfaite, on vous dit !', '10.jpg', 9, 10, 'D\'où ça vient  ?', 'Nous sommes allés chercher cette huile méconnue mais si nourrissante et si facile à utiliser dans l’Est de Madagascar.<br> Parce que nous recherchons le meilleur pour vous,<br> des savoir-faire ancestraux lointains ou oubliés,<br> nous avons ramené ce trésor de la grande île, connu sous le nom de Bakoly.', 'Comment on l\'utilise ?', 'Comptez une pipette d\'huile pour hydrater une main. <br> Huile sèche très pénétrante à appliquer sur le corps, en routine matin ou soir. <br>Elle ne laisse pas de film gras !  De même pour le visage.', 3),
(55, 'Skin city', 'Sérum de jour', 'La peau du visage est soumise à des conditions extrêmes :<br>  la météo, la pollution, le stress sont autant de facteurs qui favorisent la déshydratation et l’apparition de ridules. \r\n<br>\r\nCette alliance d’huiles pures et essentielles reconnues pour leurs propriétés protectrices, nourrissantes et hydratantes <br>sera votre nouvelle alliée contre le temps ! ', '13.jpg', 12, 10, 'D\'où ça vient  ?', 'Skin City mélange des climats et des terres différentes pour vous apporter ses richesses.<br> Les bords de l’Océan Indien, région chaude et régulièrement humide,<br> pour le kukui ; les terres rouges et arides pour le moringa ;<br> les terres vertes et tempérées du Sud-Ouest de la France pour l’huile de carthame ;<br> les hauts plateaux de Madagascar pour le citron sauvage.', 'Comment on l\'utilise ?', 'Appliquez matin et soir une pipette de Skin City sur le visage et le cou, préalablement nettoyés.<br> Notre sérum est à base d’huiles sèches, il est tout simple d’utilisation ;)', 3),
(56, 'Huile de chanvre ', 'Anti-Âge, Peaux sèches ', '<p>Secret bien gardé, l’huile de chanvre combat les signes de l’âge comme aucune autre : parfaitement équilibrée  <br>en oméga 3, 6 et 9,elle redonne douceur et élasticité à la peau. <br>\r\n\r\nC’est une huile sèche, elle peut donc remplacer vos crèmes de jour comme de nuit. <br>Laissez-vous séduire par son odeur d’herbe fraîchement coupée ; nous, on adore ! </p>', '3.jpg', 7, 10, 'D\'où ça vient  ?', 'Le chanvre peut être vu comme une « mauvaise herbe », <br>cette plante s’acclimate à de  nombreux climats différents. <br>En France, elle pousse dans les climats tempérés de l’Est du pays; <br>chez nous, dans les Ardennes.<br> Une ancienne ferme, reconvertie dans le chanvre bio, <br>entourée par la grande forêt de hêtres et de chênes.', 'Comment on l\'utilise ?', 'Sur votre visage, Le Chanvre des Secrets remplace votre  crème de jour <br>comme de nuit et convient à toutes les peaux, même les plus sensibles.<br>\r\nQuelques gouttes sur les pointes et les longueurs en soin quotidien <br>ou en masque toute la nuit avant de faire votre shampoing habituel : <br>vos cheveux sont doux, nourris et hydratés. ', 3);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `is_admin` tinyint(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `nom`, `prenom`, `adresse`, `email`, `mdp`, `is_admin`) VALUES
(12, 'bat', 'Nouheila', '9 rue du bourget', 'batnouheila@gmail.com', '202cb962ac59075b964b07152d234b70', 1),
(15, 'Bat', 'Aida', '9 rue du bourget', 'aida.bat@club-internet.fr', '202cb962ac59075b964b07152d234b70', 0),
(16, ' Bonun', ' Elodie', ' 9 rue du bourget', ' elodie@gmail.com', 'b86c434f4174e711f9611ec9fee35581', 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Index pour la table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Index pour la table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
