<?php 

require('models/Products.php');
require('models/Categories.php');

if($_GET['action'] == 'list'){
	$products = getAllProducts();
	require('views/productsList.php');
}
elseif($_GET['action'] == 'new'){
    $categories = getAllCategories();
	require('views/productsForm.php');
}
elseif($_GET['action'] == 'add'){
	
    if(empty($_POST['name']) || empty($_POST['category_id']) || empty($_POST['short_description']) || empty($_POST['description']) || empty($_POST['price']) || empty($_POST['quantity'])){
		
		if(empty($_POST['name'])){
			$_SESSION['messages'][] = 'Le champ name est obligatoire !';
        }
        if(empty($_POST['category_id'])){
			$_SESSION['messages'][] = 'Le champ categorie est obligatoire !';
        }
       
        if(empty($_POST['short_description'])){
			$_SESSION['messages'][] = 'Le champ short_description est obligatoire !';
        }
        if(empty($_POST['description'])){
			$_SESSION['messages'][] = 'Le champ description est obligatoire !';
        }
        if(empty($_POST['price'])){
			$_SESSION['messages'][] = 'Le champ price est obligatoire !';
        }
        if(empty($_POST['quantity'])){
			$_SESSION['messages'][] = 'Le champ quantity est obligatoire !';
        }
        
	
		
		$_SESSION['old_inputs'] = $_POST;
		header('Location:index.php?controller=products&action=new');
		exit;
	}
	else{
		$resultAdd = add($_POST);
		
		$_SESSION['messages'][] = $resultAdd ? 'Nouveaux produit enregistré !' : 
		"Erreur lors de l'enregistrement du produit... :(";
		
		header('Location:index.php?controller=products&action=list');
		exit;
	}
}
elseif($_GET['action'] == 'edit'){


   

    if(!empty($_POST)){

        if(empty($_POST['name']) || empty($_POST['category_id']) || empty($_POST['short_description']) || empty($_POST['description']) || empty($_POST['price']) || empty($_POST['quantity'])){

            if(empty($_POST['name'])){
                $_SESSION['messages'][] = 'Le champ name est obligatoire !';
            }
            if(empty($_POST['category_id'])){
                $_SESSION['messages'][] = 'Le champ categorie est obligatoire !';
            }
            if(empty($_POST['short_description'])){
                $_SESSION['messages'][] = 'Le champ short_description est obligatoire !';
            }
            if(empty($_POST['description'])){
                $_SESSION['messages'][] = 'Le champ description est obligatoire !';
            }
            if(empty($_POST['price'])){
                $_SESSION['messages'][] = 'Le champ price est obligatoire !';
            }
            if(empty($_POST['quantity'])){
                $_SESSION['messages'][] = 'Le champ quantity est obligatoire !';
            }
            $_SESSION['old_inputs'] = $_POST;
            header('Location:index.php?controller=products&action=edit&id='.$_GET['id']);
            exit;

        }
        else{
            $result= update($_GET['id'],$_POST);

                $_SESSION['messages'][] = $result ? 'produit mis à jour  !' : 'erreur dans la mise à jour ';


            header('Location:index.php?controller=products&action=list');
            exit;


        }

        


    }
    else{
        if (!isset($_SESSION['old_inputs'])){
			if(isset($_GET['id'])){
                $product = getProduct($_GET['id']);
				// $productCategories = getProductCategories($_GET['id']);
				if($product == false){
					$_SESSION['messages'][] = 'Merci de ne pas jouer avec les URLs ! :)';
					header('Location:index.php?controller=products&action=list');
            		exit;

				}
			}
			else{
				
				header('Location:index.php?controller=products&action=list');
            		exit;

			}
            
        }
        $categories = getAllCategories();
        require('views/productsForm.php');

    }

}
elseif($_GET['action'] == 'delete'){
	$result = delete($_GET['id']);
	if($result){
		$_SESSION['messages'][] = 'produit supprimé !';
	}
	else{
		$_SESSION['messages'][] = 'Erreur lors de la suppression... :(';
	}
	header('Location:index.php?controller=products&action=list');
	exit;
}

