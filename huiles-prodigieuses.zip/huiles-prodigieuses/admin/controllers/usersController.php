<?php
require('models/Users.php');

if($_GET['action'] == 'list'){
	$users = getAllUsers();
	require('views/usersList.php');
}
elseif($_GET['action'] == 'new'){
	require('views/usersForm.php');
}
elseif($_GET['action'] == 'add'){
	
	if(empty($_POST['nom']) || empty($_POST['prenom'])|| empty($_POST['adresse']) || empty($_POST['email'])|| empty($_POST['mdp'])){
		
		if(empty($_POST['nom'])){
			$_SESSION['messages'][] = 'Le champ name est obligatoire !';
        }
        if(empty($_POST['prenom'])){
			$_SESSION['messages'][] = 'Le champ description est obligatoire !';
		}
		if(empty($_POST['adresse'])){
			$_SESSION['messages'][] = 'Le champ description est obligatoire !';
		}
		if(empty($_POST['email'])){
			$_SESSION['messages'][] = 'Le champ description est obligatoire !';
		}
		if(empty($_POST['mdp'])){
			$_SESSION['messages'][] = 'Le champ description est obligatoire !';
		}
		$_SESSION['old_inputs'] = $_POST;
		header('Location:index.php?controller=users&action=add');
		exit;
	}
	else{
		$resultAdd = addUser($_POST);
		
		$_SESSION['messages'][] = $resultAdd ? 'User enregistré !' : 
		"Erreur lors de l'enregistrement de la user... :(";
		
		header('Location:index.php?controller=users&action=list');
		exit;
	}
}
elseif($_GET['action'] == 'edit'){



    if(!empty($_POST)){
        if(empty($_POST['nom']) || empty($_POST['prenom'])|| empty($_POST['adresse']) || empty($_POST['email'])){
			if(empty($_POST['nom'])){
				$_SESSION['messages'][] = 'Le champ name est obligatoire !';
			}
			if(empty($_POST['prenom'])){
				$_SESSION['messages'][] = 'Le champ description est obligatoire !';
			}
			if(empty($_POST['adresse'])){
				$_SESSION['messages'][] = 'Le champ description est obligatoire !';
			}
			if(empty($_POST['email'])){
				$_SESSION['messages'][] = 'Le champ description est obligatoire !';
			}
			
            
            $_SESSION['old_inputs'] = $_POST;
            header('Location:index.php?controller=users&action=edit&id='.$_GET['id']);
            exit;

        }
        else{
            $result= updateUser($_GET['id'],$_POST);

                $_SESSION['messages'][] = $result ? 'User mis à jour  !' : 'erreur dans la mise à jour ';


            header('Location:index.php?controller=users&action=list');
            exit;


        }

        


    }
    else{
        if (!isset($_SESSION['old_inputs'])){
			if(isset($_GET['id'])){
				$user = getUser($_GET['id']);
				if($user == false){
					$_SESSION['messages'][] = 'Merci de ne pas jouer avec les URLs ! :)';
					header('Location:index.php?controller=users&action=list');
            		exit;

				}
			}
			else{
				
				header('Location:index.php?controller=users&action=list');
            		exit;

			}
            
        }
       
        require('views/usersForm.php');

    }

}

elseif($_GET['action'] == 'delete'){
	$result = deleteUser($_GET['id']);
	if($result){
		$_SESSION['messages'][] = 'User supprimé !';
	}
	else{
		$_SESSION['messages'][] = 'Erreur lors de la suppression... :(';
	}
	header('Location:index.php?controller=users&action=list');
	exit;
}