<?php
require('models/Categories.php');

if($_GET['action'] == 'list'){
	$categories = getAllCategories();
	require('views/categoriesList.php');
}
elseif($_GET['action'] == 'new'){
	require('views/categoriesForm.php');
}
elseif($_GET['action'] == 'add'){
	
	if(empty($_POST['name']) || empty($_POST['description'])){
		var_dump($_POST);
	    die();
		if(empty($_POST['name'])){
			
			$_SESSION['messages'][] = 'Le champ name est obligatoire !';
        }
        if(empty($_POST['description'])){
			$_SESSION['messages'][] = 'Le champ description est obligatoire !';
		}
		
		$_SESSION['old_inputs'] = $_POST;
		header('Location:index.php?controller=categories&action=add');
		exit;
	}
	else{
		$resultAdd = addCategorie($_POST);
		
		$_SESSION['messages'][] = $resultAdd ? 'Categorie enregistré !' : 
		"Erreur lors de l'enregistrement de la categorie... :(";
		
		header('Location:index.php?controller=categories&action=list');
		exit;
	}
}
elseif($_GET['action'] == 'edit'){



    if(!empty($_POST)){

        if(empty($_POST['name']) || empty($_POST['description'])){
            if (empty($_POST['name'])){
                $_SESSION['messages'][] = 'Le champs nom est obligatoire !';
            }
            if (empty($_POST['description'])){
                $_SESSION['messages'][] = 'Le champs description est obligatoire !';
            }
            
            $_SESSION['old_inputs'] = $_POST;
            header('Location:index.php?controller=categories&action=edit&id='.$_GET['id']);
            exit;

        }
        else{
            $result= updateCategorie($_GET['id'],$_POST);

                $_SESSION['messages'][] = $result ? 'Categorie mis à jour  !' : 'erreur dans la mise à jour ';


            header('Location:index.php?controller=categories&action=list');
            exit;


        }

        


    }
    else{
        if (!isset($_SESSION['old_inputs'])){
			if(isset($_GET['id'])){
				$categorie = getCategorie($_GET['id']);
				if($categorie == false){
					$_SESSION['messages'][] = 'Merci de ne pas jouer avec les URLs ! :)';
					header('Location:index.php?controller=categories&action=list');
            		exit;

				}
			}
			else{
				
				header('Location:index.php?controller=categories&action=list');
            		exit;

			}
            
        }
       
        require('views/categoriesForm.php');

    }

}

elseif($_GET['action'] == 'delete'){
	$result = deleteCategorie($_GET['id']);
	if($result){
		$_SESSION['messages'][] = 'Categorie supprimé !';
	}
	else{
		$_SESSION['messages'][] = 'Erreur lors de la suppression... :(';
	}
	header('Location:index.php?controller=categories&action=list');
	exit;
}