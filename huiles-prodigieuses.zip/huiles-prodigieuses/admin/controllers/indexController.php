<?php 

require ('views/index.php');