<?php

function getAllProducts()
{
    $db = dbConnect();

    $query = $db->query('SELECT * FROM products');
	$products =  $query->fetchAll();

    return $products;
}

function getProduct($id){
    $db = dbConnect();
    $query=$db->prepare("SELECT * FROM products WHERE id = ?");
    $query->execute([
        $id,
	]);
	
    return $query->fetch();
	
}
function getProductCategories($id){
    $db = dbConnect();
    $query = $db->query("SELECT * FROM products WHERE category_id = ?");
    $query->execute([
        $id,
    ]);
    $result=$query->fetch();

    return $result;
}

function update( $id,$informations){
    $db = dbConnect();
    $query=$db->prepare("UPDATE products SET name = ?,short_description = ?,description = ?,price = ?,quantity = ?
	,from_title = ?,from_description = ?,use_title = ?,use_description = ? WHERE id = ?");
    $result = $query -> execute([
        $informations['name'],
		$informations['short_description'],
		$informations['description'],
		$informations['price'],
		$informations['quantity'],
		$informations['from_title'],
		$informations['from_description'],
		$informations['use_title'],
		$informations['use_description'],
        $id,

    ]);
    return $result;
}

function add($informations)
{
	$db = dbConnect();
	
	$query = $db->prepare("INSERT INTO products (name, short_description, description, price, quantity, from_title, from_description, use_title, use_description, compo_title, compo_description) 
	VALUES( :name, :short_description, :description, :price, :quantity, :from_title, :from_description, :use_title, :use_description)");
	$result = $query->execute([
		'name' => $informations['name'],
		'short_description' => $informations['short_description'],
		'description' => $informations['description'],
		'price' => $informations['price'],
		'quantity' => $informations['quantity'],
		'from_title' => $informations['from_title'],
		'from_description' => $informations['from_description'],
		'use_title' => $informations['use_title'],
		'use_description' => $informations['use_description'],
	]);

	
		if(!empty($_FILES['first_image']['tmp_name'])){

			$allowed_extensions = array( 'jpg' , 'jpeg' , 'gif', 'png' );
			$my_file_extension = pathinfo( $_FILES['first_image']['name'] , PATHINFO_EXTENSION);
				if (in_array($my_file_extension , $allowed_extensions))
				{
					$new_file_name = $productId . '.' . $my_file_extension ;
					$destination = '../assets/img/product/' . $new_file_name;
					$result = move_uploaded_file( $_FILES['image']['tmp_name'], $destination);
					$db->query("UPDATE products SET first_image = '$new_file_name' WHERE id = $productId");
				}

		}
		
		
	
	
	return $result;
}

function delete($id)
{
	$db = dbConnect();
	
	//ne pas oublier de supprimer le fichier lié s'il y en un
	//avec la fonction unlink de PHP
	
	$query = $db->prepare('DELETE FROM products WHERE id = ?');
	$result = $query->execute([$id]);
	
	return $result;
}