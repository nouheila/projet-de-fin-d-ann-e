<?php
function getAllCategories()
{
    $db = dbConnect();

    $query = $db->query('SELECT * FROM categories');
	$categories =  $query->fetchAll();

    return $categories;
}

function getCategorie($id){
    $db = dbConnect();
    $query=$db->prepare("SELECT * FROM categories WHERE id = ?");
    $query->execute([
        $id,
    ]);
    $result=$query->fetch();

    return $result;
}


function updateCategorie($id,$informations){
    $db = dbConnect();
    
    $query=$db->prepare("UPDATE categories SET name = ?, description = ? WHERE id = ?");
    $result = $query -> execute([
        $informations['name'],
        $informations['description'],
        $id,

    ]);
    
    return $result;
}

function addCategorie($informations)
{
   
	$db = dbConnect();
	$query = $db->prepare("INSERT INTO categories (name, description) VALUES ( :name, :description) ");
	$result = $query->execute([
        'name' => $informations['name'],
        'description' => $informations['description'],
		
    ]);
    if(!empty($_FILES['first_image']['tmp_name'])){

        $allowed_extensions = array( 'jpg' , 'jpeg' , 'gif', 'png' );
        $my_file_extension = pathinfo( $_FILES['first_image']['name'] , PATHINFO_EXTENSION);
            if (in_array($my_file_extension , $allowed_extensions))
            {
                $new_file_name = $productId . '.' . $my_file_extension ;
                $destination = '../assets/img/categorie/' . $new_file_name;
                $result = move_uploaded_file( $_FILES['image']['tmp_name'], $destination);
                $db->query("UPDATE products SET first_image = '$new_file_name' WHERE id = $productId");
            }

    }

	
	return $result;
}

function deleteCategorie($id)
{
	$db = dbConnect();
	
	//ne pas oublier de supprimer le fichier lié s'il y en un
	//avec la fonction unlink de PHP
	
	$query = $db->prepare('DELETE FROM categories WHERE id = ?');
	$result = $query->execute([$id]);
	
	return $result;
}