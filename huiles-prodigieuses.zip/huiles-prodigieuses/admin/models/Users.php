<?php

function getAllUsers()
{
    $db = dbConnect();

    $query = $db->query('SELECT * FROM user');
	$users =  $query->fetchAll();

    return $users;
}

function getUser($id){
    $db = dbConnect();
    $query=$db->prepare("SELECT * FROM user WHERE id = ?");
    $query->execute([
        $id,
	]);
	
    return $query->fetch();
	
}

function updateUser( $id,$informations){
    $db = dbConnect();
    $query=$db->prepare("UPDATE user SET nom = ?, prenom = ?, adresse = ?, email = ?,mdp = ? WHERE id = ?");
    $result = $query -> execute([
        $informations['nom'],
		$informations['prenom'],
		$informations['adresse'],
		$informations['email'],
		$informations['mdp'],
        $id,

    ]);
    return $result;
}

function addUser($informations)
{
	$db = dbConnect();
	
	$query = $db->prepare("INSERT INTO user (nom, prenom, adresse, email, mdp) VALUES( :nom, :prenom, :adresse, :email, :mdp)");
	$result = $query->execute([
		'nom' => $informations['nom'],
		'prenom' => $informations['prenom'],
		'adresse' => $informations['adresse'],
		'email' => $informations['email'],
		'mdp' => hash('md5', $informations['mdp']),
	]);
	
	return $result;
}

function deleteUser($id)
{
	$db = dbConnect();
	
	//ne pas oublier de supprimer le fichier lié s'il y en un
	//avec la fonction unlink de PHP
	
	$query = $db->prepare('DELETE FROM user WHERE id = ?');
	$result = $query->execute([$id]);
	
	return $result;
}