

<?php include ('partials/header.php') ?>

<div class="alert alert-dark text-center" style="font-size:20px;" role="alert">
<?php if(isset($_SESSION['messages'])): ?>
	<div>
		<?php foreach($_SESSION['messages'] as $message): ?>
			<?= $message ?><br>
		<?php endforeach; ?>
	</div>
<?php endif; ?>

</div>




<p class="h2 text-center" style ="margin-top : 50px;">Liste des produits</p>
<div style="padding-left :100px; ">
    <a href="index.php"><button type="button" class="btn btn-dark">Page d'accueil</button></a>
</div>
<div class="text-center">
    <a href="index.php?controller=products&action=new"><button type="button" class="btn btn-success">Ajouter un produit</button></a>
</div>


    <table class="table " style="margin-top:50px;">
    
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nom du produit</th>
      
     <!-- <th scope="col">Nom de la catégorie</th>-->
      <th scope="col">Modifier</th>
      <th scope="col">Supprimer</th>
      
     
  </thead>
  <tbody>
  <?php foreach($products as $product): ?>
    <tr>
      <th scope="row" ><?= $product['id'] ?></th>
      <td><p><?=  htmlspecialchars($product['name']) ?> </td>
      <td><a href="index.php?controller=products&action=edit&id=<?= $product['id'] ?>"><button type="button" class="btn btn-primary">Modifier</button></a></td>
      <td><a href="index.php?controller=products&action=delete&id=<?= $product['id'] ?>"><button type="button" class="btn btn-danger">Supprimer</button></a></p></td>
    </tr>
  <?php endforeach; ?>

  </tbody>
</table>	


