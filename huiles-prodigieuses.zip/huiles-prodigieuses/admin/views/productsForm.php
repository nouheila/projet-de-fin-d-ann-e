
<?php include ('partials/header.php') ?>

<div class="alert alert-dark text-center" style="font-size:20px;" role="alert">
<?php if(isset($_SESSION['messages'])): ?>
	<div>
		<?php foreach($_SESSION['messages'] as $message): ?>
			<?= $message ?><br>
		<?php endforeach; ?>
	</div>
<?php endif; ?>

</div>

<p class="h2 text-center" style ="margin-top : 50px;">Formulaire d'un produit</p>
<div class="text-center">
    <a href="index.php?controller=products&action=list"><button type="button" class="btn btn-success">Liste des produits</button></a>
</div>



<form action="index.php?controller=products&action=<?= isset($product) || 
(isset($_SESSION['old_inputs']) && $_GET['action'] != 'new') ? 'edit&id='.$_GET['id'] : 
'add'?>" method="post" enctype="multipart/form-data" style ="margin-top : 50px;">

  <div class="form-group" style ="margin-bottom:50px;  padding-left:10px;">

    <label for="name">Nom du produit</label>
    <input type="text" class="form-control"  style="width:500px;"id="name" name="name" value="<?= isset($_SESSION['old_inputs']) ? 
  $_SESSION['old_inputs']['name'] : '' ?><?= isset($product) ? $product['name'] : '' ?>" >
  
  </div>
  <div class="form-group" style ="margin-bottom:50px;  padding-left:10px;">
    <label for="category_id">Catégorie</label>
    <select multiple class="form-control" id="category_id"   style="width:500px;" name="category_id[]">
    <?php foreach($categories as $categorie): ?>
			 <?php
			 $selected = false;
			 	foreach($productCategories as $productCategorie){
					 if($categorie['id'] == $productCategorie['id']){
						 $selected = true;
					 }
				 }
			 ?>
        <option value="<?= $categorie['id'];?>"<?php if(isset($product) && $selected == true):?>selected ="selected"
		<?php endif;?>><?= $categorie['name'];?></option>
        <?php endforeach; ?>
    </select>
  </div>
  <div class="form-group" style ="margin-bottom:50px;">
    <label for="short_description">Short description</label>
    <input type="text" class="form-control"  style="width:500px;"id="short_description" name="short_description" value="<?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['short_description'] : '' ?><?= isset($product) ? $product['short_description'] : '' ?>" >
  </div>
  
  <div class="form-group">
    <label for="desciption">Description</label>
    <textarea class="form-control" id="description" name="description" rows="3"><?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['description'] : '' ?><?= isset($product) ? $product['description'] : '' ?></textarea>
  </div>
  <div class="form-group">
    <label for="price">Prix</label>
    <input type="text" class="form-control" id="price" name="price" value="<?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['price'] : '' ?><?= isset($product) ? $product['price'] : '' ?>" >
  </div>
  <div class="form-group">
    <label for="quantity">Quantité</label>
    <input type="text" class="form-control" id="quantity" name="quantity" value="<?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['quantity'] : '' ?><?= isset($product) ? $product['quantity'] : '' ?>" >
  </div>
<div class="form-group">
    <label for="first_image">Image principal</label>
    <input type="file" class="form-control-file" id="first_image" name="first_image">
  </div>

  <div class="form-group" style ="margin-bottom:50px;">
    <label for="from_title">Article 1 : titre</label>
    <input type="text" class="form-control"  style="width:500px;"id="from_title" name="from_title" value="<?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['from_title'] : '' ?><?= isset($product) ? $product['from_title'] : '' ?>" >
  </div>
  <div class="form-group">
    <label for="from_description">Article 1 : Description</label>
    <textarea class="form-control" id="from_description" name="from_description" rows="3"><?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['from_description'] : '' ?><?= isset($product) ? $product['from_description'] : '' ?></textarea>
  </div>
  

  <div class="form-group" style ="margin-bottom:50px;">
    <label for="use_title">Article 2 : titre</label>
    <input type="text" class="form-control"  style="width:500px;"id="use_title" name="use_title" value="<?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['use_title'] : '' ?><?= isset($product) ? $product['use_title'] : '' ?>" >
  </div>
  <div class="form-group">
    <label for="use_description">Article 2 : Description</label>
    <textarea class="form-control" id="from_description" name="use_description" rows="3"><?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['use_description'] : '' ?><?= isset($product) ? $product['use_description'] : '' ?></textarea>
  </div>
  
  
  

  <div class="text-center">
  <button type="submit" class="btn btn-primary">Enregistrer</button>
  </div>
  
	

</form>
	
</body>
</html>


