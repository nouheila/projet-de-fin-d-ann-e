
<?php include ('partials/header.php') ?>

<div class="alert alert-dark text-center" style="font-size:20px;" role="alert">
<?php if(isset($_SESSION['messages'])): ?>
	<div>
		<?php foreach($_SESSION['messages'] as $message): ?>
			<?= $message ?><br>
		<?php endforeach; ?>
	</div>
<?php endif; ?>

</div>

<p class="h2 text-center" style ="margin-top : 50px;">Formulaire d'une categorie</p>
<div class="text-center">
    <a href="index.php?controller=categories&action=list"><button type="button" class="btn btn-success">Liste des categories</button></a>
</div>



<form action="index.php?controller=categories&action=<?= isset($categorie) || 
(isset($_SESSION['old_inputs']) && $_GET['action'] != 'new') ? 'edit&id='.$_GET['id'] : 
'add'?>" method="post" enctype="multipart/form-data" style ="margin-top : 50px;">

  <div class="form-group" style ="margin-bottom:50px;  padding-left:10px;">
    <label for="name">Nom de la Categorie</label>
    <input type="text" class="form-control"  style="width:500px;" id="name" name="name" value="<?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['name'] : '' ?><?= isset($categorie) ? $categorie['name'] : '' ?>" >
  </div>

  <div class="form-group" style ="margin-bottom:50px;  padding-left:10px;">
    <label for="description">Description</label>
    <input type="text" class="form-control"  style="width:500px;"id="description" name="description" value="<?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['description'] : '' ?><?= isset($categorie) ? $categorie['description'] : '' ?>" >
  </div>
 
 
<!-- <div class="form-group">
    <label for="first_image">Image principal</label>
    <input type="file" class="form-control-file" id="first_image" name="first_image">
  </div> -->
  <div class="text-center">
  <button type="submit" class="btn btn-primary">Enregistrer</button>
  </div>
  
	

</form>
	
</body>
</html>


