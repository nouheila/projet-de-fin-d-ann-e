
<?php include ('partials/header.php') ?>

<div class="alert alert-dark text-center" style="font-size:20px;" role="alert">
<?php if(isset($_SESSION['messages'])): ?>
	<div>
		<?php foreach($_SESSION['messages'] as $message): ?>
			<p><?= $message ?></p>
		<?php endforeach; ?>
	</div>
<?php endif; ?>

</div>

<p class="h2 text-center" style ="margin-top : 50px;">Formulaire d'un User</p>
<div class="text-center">
    <a href="index.php?controller=users&action=list"><button type="button" class="btn btn-success">Liste des users</button></a>
</div>



<form action="index.php?controller=users&action=<?= isset($user) || 
(isset($_SESSION['old_inputs']) && $_GET['action'] != 'new') ? 'edit&id='.$_GET['id'] : 
'add'?>" method="post" enctype="multipart/form-data" style ="margin-top : 50px;">

  <div class="form-group" style ="margin-bottom:50px;  padding-left:10px;">
    <label for="nom">Nom :</label>
    <input type="text" class="form-control"  style="width:500px;" id="nom" name="nom" value="<?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['nom'] : '' ?><?= isset($user) ? $user['nom'] : '' ?>" >
  </div>

  <div class="form-group" style ="margin-bottom:50px;  padding-left:10px;">
    <label for="prenom">Prénom :</label>
    <input type="text" class="form-control"  style="width:500px;"id="prenom" name="prenom" value="<?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['prenom'] : '' ?><?= isset($user) ? $user['prenom'] : '' ?>" >
  </div>
  <div class="form-group" style ="margin-bottom:50px;  padding-left:10px;">
    <label for="adresse">Adresse :</label>
    <input type="text" class="form-control"  style="width:500px;"id="adresse" name="adresse" value="<?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['adresse'] : '' ?><?= isset($user) ? $user['adresse'] : '' ?>" >
  </div>
  <div class="form-group" style ="margin-bottom:50px;  padding-left:10px;">
    <label for="email">Email :</label>
    <input type="text" class="form-control"  style="width:500px;"id="email" name="email" value="<?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['email'] : '' ?><?= isset($user) ? $user['email'] : '' ?>" >
  </div>
  <div class="form-group" style ="margin-bottom:50px;  padding-left:10px;">
    <label for="mdp">Mot de passe :</label>
    <input type="password" class="form-control"  style="width:500px;"id="mdp" name="mdp" value="<?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['mdp'] : '' ?><?= isset($user) ? $user['mdp'] : '' ?>" >
  </div>
  
  
  
 

  <div class="text-center">
  <button type="submit" class="btn btn-primary">Enregistrer</button>
  </div>
  
	

</form>
	
</body>
</html>


