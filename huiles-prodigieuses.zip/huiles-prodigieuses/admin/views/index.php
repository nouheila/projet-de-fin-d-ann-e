<?php include ('partials/header.php') ?>
<div class="text-center">
    <a href="../index.php"><button style="margin-top:15px;" type="button" class="btn btn-success"> Lien vers le site </button></a>
</div>