<?php
session_start();
require('helpers.php');

//routeur du site
//appel un controleur selon la valeur de $_GET['page'] (la page demandée)
//si pas de $_GET['page'] ou que $_GET['page'] ne correspond à rien de voulu, affichage de la page index

if(isset($_GET['page'])){

  switch ($_GET['page']) {
    case 'product_list' :
  		require 'controllers/productListController.php';
  		break;

      case 'product' :
      	require 'controllers/productController.php';
		  break;

	  case 'connexionIncription' :
		 require 'controllers/connexionInscriptionController.php';
		 break;

	  case 'pageMembre' :
		require 'controllers/membreController.php';
	    break;
	   

  	   require 'controllers/indexController.php';
  }

}
else{
  require 'controllers/indexController.php';
}

if(isset($_SESSION['messages'])){
    unset($_SESSION['messages']);
}
if(isset($_SESSION['old_inputs'])){
    unset($_SESSION['old_inputs']);
}