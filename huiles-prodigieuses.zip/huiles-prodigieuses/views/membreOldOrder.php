
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css"/>
      <link rel="stylesheet" href="asset/css/style.css">
      <title>Document</title>
  </head>
  <body>
        
  <section>
        <div class="membre">
            <div class="dashbord">
                <div class="text">
                   
                    <p><i class="fas fa-home"></i> <a href = "index.php">Accueil</a></p>
                    <p> <i class="fas fa-user"></i><a href ="index.php?page=pageMembre&action=edit&id=<?= $_SESSION['user']['id'] ?>">Compte</a></p>
                    <p><i class="fas fa-shopping-cart"></i><a href="index.php?page=pageMembre&action=list">Commandes</a></p>
                    <p><i class="fas fa-sign-out-alt"></i><a href ="index.php?page=connexionIncription&action=disconnect">deconnexion</a></p>
                    
                  
                </div>
               
                
            </div>

           
                <div class="orders">
                    <h2>Vos commandes</h2>
                    <table>
                        <thead>
                           
                            <tr>
                              <th scope="col">Produit</th>
                              <th scope="col">Quantité</th>
                              <th scope="col">Total</th>
                              <th scope="col">Livraison</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>Huile de jojoba</td>
                              <td>2</td>
                              <td>15.80 €</td>
                              <td>En cours de livraison</td>
                            </tr>
                        </tbody> 
        
                    </table>

                </div>
                
        
    
        </div>
            
        
       
    </section>
    
  
   <script src="asset/js/main.js"></script> 
  </body>
  </html>















        
                