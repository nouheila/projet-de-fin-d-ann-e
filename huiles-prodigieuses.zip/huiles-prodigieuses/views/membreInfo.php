
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css"/>
      <link rel="stylesheet" href="asset/css/style.css">
      <title>Document</title>
  </head>
  <body>
        
  <section>
        <div class="membre">
        <div class="dashbord">
                <div class="text">
                   
                <p><i class="fas fa-home"></i> <a href = "index.php">Accueil</a></p>
                    <p> <i class="fas fa-user"></i><a href ="index.php?page=pageMembre&action=edit&id=<?= $_SESSION['user']['id'] ?>">Compte</a></p>
                    <p><i class="fas fa-shopping-cart"></i><a href="index.php?page=pageMembre&action=list">Commandes</a></p>
                    <p><i class="fas fa-sign-out-alt"></i><a href ="index.php?page=connexionIncription&action=disconnect">deconnexion</a></p>
                    
                </div>
            </div>

           
                <div class="edit">
                    <form action="" method="post">
                        
                        <label for="nom">Nom :
                            <input type="text" id="nom" name="nom" value=" <?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['nom'] : '' ?><?= isset($user) ? $user['nom'] : '' ?>">
                        </label>
                        <label for="prenom">Prénom :
                            <input type="text" id="prenom" name="prenom" value=" <?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['prenom'] : '' ?><?= isset($user) ? $user['prenom'] : '' ?>">
                        </label>
                        <label for="adresse">Adresse :
                            <input type="text" id="adresse" name="adresse" value=" <?= isset($_SESSION['old_inputs']) ? 
	                        $_SESSION['old_inputs']['adresse'] : '' ?><?= isset($user) ? $user['adresse'] : '' ?>">
                        </label>
                        <label for="email">E-mail :
                            <input type="text" id="email" name="email" value=" <?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['email'] : '' ?><?= isset($user) ? $user['email'] : '' ?>">
                        </label>
                        <label for="mdp">Mot de passe  :
                            <input type="password" id="mdp" name="mdp" value=" <?= isset($_SESSION['old_inputs']) ? 
	$_SESSION['old_inputs']['mdp'] : '' ?><?= isset($user) ? $user['mdp'] : '' ?>">
                        </label>
                        <button type="submit" class="submit">Enregistrer</button>
                    </form>
                </div>
                
        
    
        </div>
            
        
       
    </section>
    
  
   <script src="asset/js/main.js"></script> 
  </body>
  </html>















        
                