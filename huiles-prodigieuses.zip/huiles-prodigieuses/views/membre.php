
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css"/>
      <link rel="stylesheet" href="asset/css/style.css">
      <title>Document</title>
  </head>
  <body>
        
  <section>
        <div class="membre">
            <div class="dashbord">
                <div class="text">
                   
                    <p><i class="fas fa-home"></i> <a href = "index.php">Accueil</a></p>
                    <p> <i class="fas fa-user"></i><a href ="index.php?page=pageMembre&action=edit&id=<?= $_SESSION['user']['id'] ?>">Compte</a></p>
                    <p><i class="fas fa-shopping-cart"></i><a href="index.php?page=pageMembre&action=list">Commandes</a></p>
                    <p><i class="fas fa-sign-out-alt"></i><a href ="index.php?page=connexionIncription&action=disconnect">deconnexion</a></p>
                    
                </div>
            </div>
            <div class="hello">
                <h2>Bonjour <?= $_SESSION['user']['prenom'] ?></h2>
                <p> 
                    Bienvenue dans votre espace client ! <br>
                    Vous pouvez suivre vos commandes, Gérer vos adresses de  <br>
                    livraisons et modifier vos informations personnelles  <br>
                </p>
            </div>

        </div>

    </section>
  
   <script src="asset/js/main.js"></script> 
  </body>
  </html>















        
                