<!DOCTYPE html>
<html>
<head>
	<title>Inscription/connexion</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css"/>
    <link rel="stylesheet" href="asset/css/connexion.css">
   

</head>
<body>


  <div class="cont">
    <div class="form sign-in">
      <h2>Connexion</h2>
      <form  method="POST" action="index.php?page=connexionIncription&action=connexion">
      <label for="email">
        <span>Email</span>
        <input type="email" name="email" id="email" required>
      </label>
      <label for="mdp">
        <span>Mot de passe </span>
        <input type="password" name="mdp" id="mdp" required>
      </label>
      <button class="submit" type="submit" name="connexion">Connexion</button>
    </form>
      <p class="forgot-pass">Mot de passe oublié ?</p>

      <div class="social-media">
        <ul>
          <li><img src="./asset/images/facebook.png"></li>
          <li><img src="./asset/images/twitter.png"></li>
          <li><img src="./asset/images/linkedin.png"></li>
          <li><img src="./asset/images/instagram.png"></li>
        </ul>
      </div>
    </div>
   
    <div class="sub-cont">
      <div class="img">
        <div class="img-text m-up">
          <h2>Pas Inscrit?</h2>
          <p>Inscrivez-vous pour accéder à votre espace perso !</p>
        </div>
        <div class="img-text m-in">
          <h2>Inscrit?</h2>
          <p>Connectez-vous pour accéder à votre espace perso !</p>
        </div>
        <div class="img-btn">
          <span class="m-up">Inscription</span>
          <span class="m-in">Connexion</span>
        </div>
      </div>
      
      <div class="form sign-up">
        <h2>Inscription</h2>
        <form  method="POST" action="index.php?page=connexionIncription&action=inscription"> 
        <label for="nom">
          <span>Nom</span>
          <input type="nom" name="nom" id="nom">
        </label>
        <label for="prenom">
          <span>Prénom</span>
          <input type="prenom" name="prenom" id="prenom" >
        </label>
        <label for="adresse">
          <span>Adresse</span>
          <input type="adresse" name="adresse" id="adresse" >
        </label>
        <label for="email">
          <span>Email</span>
          <input type="email" name="email" id="email">
        </label>
        <label for="mdp">
          <span>Mot de passe</span>
          <input type="password" name="mdp" id="mdp">
        </label>
        <button type="submit" name="inscription" class="submit">Inscription</button>
      
      </form>
      
      </div>
    </div>
  </div>
  
 
<script type="text/javascript" src="./asset/js/script.js"></script>
</body>
</html>