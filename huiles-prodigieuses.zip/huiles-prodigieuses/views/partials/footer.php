<footer class="footer">
        <div class="container">
            <div class="container-info">
                <div class="text-info">
                    <p>Contacter-nous</p>
                </div>
                <div class="img-info">
                    <img src="asset/img/valeurs/phone.png" alt="">
                </div>
                <div class="text-info">
                    <p>Du lundi au vendredi 9h-17h</p>
                </div> 
            </div>
            <div class="container-info">
                <div class="text-info">
                    <p>Paiement sécurisé</p>
                </div>
                <div class="img-info">
                    <img src="asset/img/valeurs/key.png" alt="">
                </div>
                <div class="text-info">
                    <p>Acheter en toute confiance</p>
                </div> 
            </div>
            <div class="container-info">
                <div class="text-info">
                    <p>Echange & retour</p>    
                </div>
                <div class="img-info">
                <img src="asset/img/valeurs/echange.png" alt="">
                </div>
                <div class="text-info">
                    <p>Retour gratuit sous 30 jours</p>
                </div> 
            </div>
            <div class="container-info">
                <div class="text-info">
                    <p>Livraison</p>
                </div>
                <div class="img-info">
                <img src="asset/img/valeurs/truck.png" alt="">
                </div>
                <div class="text-info">
                    <p>Livraison gratuit sous 48H</p>
                </div> 
            </div>
        </div>
    </footer>
    




    <script src="asset/js/main.js"></script>
</body>
</html>

