<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>Huiles pridigieuses</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css"/>
    <link rel="stylesheet" href="./asset/css/style.css">

</head>
<body>

   
    <nav class="nav flex-row">
        <div class="nav-menu">
            <div class="nav-brand">
               <a href="index.php">Huiles prodigieuses</a> 
            </div>
        </div>
        <div class="toggle-collapse">
            <div class="toggle-icons">
                <span><i class="fas fa-bars"></i></span>
            </div>
        </div>
        <div>
       
            <ul class="nav-items flex-row">
            <?php foreach($categories as $category): ?>
                <li class="nav-link">
                <a href="index.php?page=product_list&category_id=<?= $category['id'] ?>"><?= $category['name']; ?></a>
                </li>
			
		<?php endforeach; ?>
            
                <li class="nav-link">
                    <a href="index.php?page=connexionIncription&action=formulaire">Connexion / Inscription</a>
                </li>
                
            </ul>
          
        </div>

        <div class="icons">

            <i class="fas fa-search"></i>
           <a href="index.php?page=<?=isset($_SESSION['user'])  ? 'pageMembre' : 'connexionIncription' ?>&action=<?=isset($_SESSION['user'])   ? 'membre' : 'inscription'?>"><i class="far fa-user"></i></a> 
            <i class="fas fa-shopping-bag"></i>

        </div>
      </nav>

    