
<?php require 'partials/header.php'; ?>

    <section>
   
        <div class="banner">
        <a href="index.php"><p>Accueil / </p></a>
        
        <p> <?= $selectedProduct['name']; ?></p>     
        </div>
        
    </section>
    <section class="fiche-produit">
        <div class="container-fiche">
        
            <div class="fiche-image">
                <img src="asset/img/product/<?= $selectedProduct['first_image']; ?>" alt="<?= $selectedProduct['name']; ?>">
            </div>
            
        </div>
        <div class="container-fiche">
            <div class="fiche-text">
                <h3><?= $selectedProduct['name']; ?></h3>
                <h3><?= $selectedProduct['price']; ?> €</h3>
                <p>
                <?= $selectedProduct['description']; ?>
                </p>
                <label class="qty" for="quantity">
                     Quantité
                    <input id="quantity" type="number" value="0" min="0" max="10">
                </label>
                <input id="panier" type="submit" value="Ajouter au panier">
            </div>

        </div>    
    </section>
    <section class="info-produit">
        
            <div class="info-container">
                <div class="info-image">
                    <img src="asset/img/Instagram/from.jpeg" alt="">
                </div>
            
            
                <div class="info-text">
                    <h2><?= $selectedProduct['from_title']; ?></h2>
                    <p>
                    <?= $selectedProduct['from_description']; ?>
                    </p>
                </div>
            </div>
            <div class="info-container">
                <div class="info-image">
                    <img src="asset/img/Instagram/use.jpg" alt="">
                </div>
                <div class="info-text">
                    <h2><?= $selectedProduct['use_title']; ?></h2>
                    <p>
                    <?= $selectedProduct['use_description']; ?>
                    </p>
                </div>
            
            
                
            </div>
            
    
    
            
        
        
    </section>

  
    <?php require 'partials/footer.php'; ?>
