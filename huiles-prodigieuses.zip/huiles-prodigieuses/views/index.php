<?php require 'partials/header.php'; ?>
    
      <section class="prez">
        <div class="container-prez">
            <div class="img-prez">
                <div class="text-prez">
                    <h2>Huiles Prodigieuses</h2>
                    <p>Votre partenaire beauté  <br>au quotidien</p>
                </div>     
            </div>
        </div> 
    </section>

    <section class="cate">
        <div class="container">
      
        <?php foreach($categories as $category): ?>
            <div class="container-cate">
        
                <div class="img-cate">
                <img src="asset/img/categorie/<?= $category['image']; ?>" alt="<?= $category['name']; ?>">                
                </div>
                    <div class="text-cate">
                    <a href="index.php?page=product_list&category_id=<?= $category['id'] ?>"><p><?= $category['name']; ?><p></a>
                </div>                
            </div> 
            <?php endforeach; ?>  
        </div>
              
    </section>

    <section class="fav-pro">
    <?php $selectedProduct = []; ?>
        <h2>Produits phare</h2>
            <div class="container">
            <?php foreach($products as $product): ?>
                    <div class="container-fav-pro">
                        <div class="img-fav-pro">
                        <img src="asset/img/product/<?= $product['first_image']; ?>" alt="<?= $product['name']; ?>">
                        </div>
                        <div class="text-fav-pro">
                            <h3><?= $product['name']; ?></h3>
                            <p><?= $product['short_description']; ?></p>
                            <h3><?= $product['price']; ?>€</h3>
                            <button><a href="index.php?page=product&product_id=<?= $product['id']; ?>">Voir plus</a></button>
                        </div>
                    </div>

            <?php endforeach; ?>
                    
                    

            </div>
    </section>

    <section class="valeur">
            <h2>Nos valeur</h2>

            <div class="container">
                <div class="container-valeur">
                    <div class="img-valeur">
                        <img src="./asset/img/valeurs/lapin.png" alt="">
                    </div>
                    <div class="text-valeur">
                        <p>
                            Produits vegan et  <br> testés 
                            sur les animaux
                        </p>
                    </div>
                </div>
                <div class="container-valeur">
                    <div class="img-valeur">
                        <img src="asset/img/valeurs/bio.png" alt="">
                    </div>
                    <div class="text-valeur">
                        <p>
                           Pas de produit chimique<br>
                            pur et naturel
                        </p>
                    </div>
                </div>
                <div class="container-valeur">
                    <div class="img-valeur">
                        <img src="asset/img/valeurs/recyclable.png" alt="">
                    </div>
                    <div class="text-valeur">
                        <p>
                        Flacons 100% recyclables <br>
                        et fabriqué en Europe
                        </p>
                    </div>
                </div>
                <div class="container-valeur">
                    <div class="img-valeur">
                        <img src="asset/img/valeurs/soleil.png" alt="">
                    </div>
                    <div class="text-valeur">
                        <p>
                        Conditionnées en France<br>
                        Cocorico !
                        </p>
                    </div>
                </div>

            </div>
            
            
            <button id="valeur"><a href="#">Nous découvrir</a></button>
         
    </section>
    <?php require 'partials/footer.php'; ?>
