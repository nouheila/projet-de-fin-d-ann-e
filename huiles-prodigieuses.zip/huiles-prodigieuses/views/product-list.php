

    <?php require 'partials/header.php'; ?>


    <section>
        <div class="banner">
        <a href="index.php"><p>Accueil / </p></a>
        <?php if($selectedCategory != false): ?>
                    
                    <p> <?= $selectedCategory['name']; ?></p>
                <?php endif; ?>
           
            
        </div>
        
    </section>


    <section>
        <div class="description">
            <p>
            <?= $selectedCategory['description']; ?>
            </p>
        </div>
    </section>

    <section>
   
            <div class="produits">
           
            <?php foreach($products as $product): ?>
                         <div class="produit">
                            <div class="img-produit">
                            <img src="asset/img/product/<?= $product['first_image']; ?>" alt="<?= $product['name']; ?>">
                            </div>
                            <div class="text-produit">
                                <h3><?= $product['name']; ?></h3>
                                <p><?= $product['short_description']; ?></p>
                                <h3><?= $product['price']; ?> €</h3>
                                <button><a href="index.php?page=product&product_id=<?= $product['id']; ?>">Voir plus</a></button>
                            </div>

                         </div>

            <?php endforeach; ?>
                         
                        
                         
            </div>
        </section>
        <?php require 'partials/footer.php'; ?>
