<?php
require ('models/ConnexionInscription.php');



if($_GET['action'] == 'formulaire'){
  require ('views/connexionInscription.php');
  exit;

}
elseif($_GET['action'] == 'inscription'){

    if(empty($_POST['nom']) || empty($_POST['prenom']) || empty($_POST['adresse']) || empty($_POST['email']) || empty($_POST['mdp'])){
      $message = 'tous les champs sont obligatoire';
      header('Location:index.php?page=connexionIncription&action=formulaire');
      exit;
    }
    else{

       $emailExists = getEmail();

      if(!$emailExists){

       
        $resultAdd = addUser($_POST);
        $_SESSION['user'] = $user;
      

        header('Location:index.php?page=pageMembre&action=membre');
      }

      else{
        $_SESSION['messages'][]  = 'email déjà utilisé';
        header('Location:index.php?page=connexionIncription&action=formulaire');
        exit;
      }
    }
    
}

elseif($_GET['action'] == 'connexion')
  {
    if(empty($_POST['email']) || empty($_POST['mdp']))
    {
      
      $_SESSION['messages'][] = 'email et mot de passe obligatoires';
      header('Location:index.php?page=connexionIncription&action=formulaire');
      exit;

    }
    else{
         
         $user = getUser($_POST);
         
         if($user){

          $_SESSION['user'] = $user;

          
          if($_SESSION['user']['is_admin'] == 1){

            header('Location:admin/index.php');
            exit;
          }
            else {

              header('Location:index.php?page=pageMembre&action=membre');
              exit;
          
            }
        }

          else{
            $_SESSION['messages'][] = 'mauvais identifiants !';
        }

    }

  }

  elseif(isset($_GET['action']) && $_GET['action'] == 'disconnect'){
    unset($_SESSION['user']);
    header('Location:index.php');
    exit;
  }


  