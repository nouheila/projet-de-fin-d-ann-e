<?php 
require 'models/connexionInscription.php';

if($_GET['action'] == 'membre'){

    require ('views/membre.php');
    exit;
}
elseif($_GET['action'] == 'edit'){

    if(!empty($_POST))
    {
        if(empty($_POST['nom']) || empty($_POST['prenom'])|| empty($_POST['adresse']) || empty($_POST['email']))
        {
			if(empty($_POST['nom'])){
				$_SESSION['messages'][] = 'Le champ name est obligatoire !';
			}
			if(empty($_POST['prenom'])){
				$_SESSION['messages'][] = 'Le champ description est obligatoire !';
			}
			if(empty($_POST['adresse'])){
				$_SESSION['messages'][] = 'Le champ description est obligatoire !';
			}
			if(empty($_POST['email'])){
				$_SESSION['messages'][] = 'Le champ description est obligatoire !';
			}
			
            
            $_SESSION['old_inputs'] = $_POST;
            header('Location:index.php?page=pageMembre&action=edit&id='.$_GET['id']);
           
        }
        
            else{

                $result= updateUser($_GET['id'],$_POST);

                $_SESSION['messages'][] = $result ? 'User mis à jour  !' : 'erreur dans la mise à jour ';
                header('Location:index.php?page=pageMembre&action=membre');
               
            }
    }
        else 
        {
            
            if(!isset($_SESSION['old_inputs']))
            {
                if(isset($_GET['id']))
                {
                    $user = getUserId($_GET['id']);
                    if($user == false)
                    {
                        header('Location:index.php?page=pageMembre&action=membre');
                        
                    }
                }
                else
                {
                    header('Location:index.php?page=pageMembre&action=membre');
                    
                }
    
            }
            require ('views/membreInfo.php');
           
            
        }
        
        
    }
    elseif($_GET['action'] == 'list'){
        require ('views/membreOldOrder.php');
       
    }
    

