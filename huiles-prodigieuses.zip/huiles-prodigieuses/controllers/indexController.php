<?php

//appel des données à exploiter
require_once 'models/Category.php';
require_once 'models/Product.php';


$products = getHomeProducts();
$categories = getCategories();

//appel de la vue correspondante
include 'views/index.php';

